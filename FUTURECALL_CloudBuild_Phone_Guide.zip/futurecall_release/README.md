# FUTURECALL Research v0.1

This starter kit contains:
- `www/`: installable PWA prototype (runs in a modern browser; can be added to home screen when served over HTTPS).
- `android/`: Android Studio project wrapper around the local HTML prototype.

## What works
- Five-symbol prediction trials (A-E)
- ISO UTC timestamps
- SHA-256 digest of the committed prediction record
- Waits 30 seconds before generating a target with Web Crypto randomness
- Exact-match scoring, local trial history, JSON export
- Local storage only; no backend or account

## Scientific caveats
The target is generated randomly after the prediction is committed. This protocol tests a narrow prediction task; it does not provide a mechanism for future-to-past messaging. A hit is not proof. For a serious study, preregister hypotheses and sample size, use independent audit and blinding, publish the code and protocol, and analyze all trials (not selected successes). The current prototype's UI/browser environment is not a tamper-proof scientific instrument.

## Build APK
Open the `android/` folder in Android Studio with JDK 17 and Android SDK platform 35 installed. Let Gradle sync, then choose **Build > Build Bundle(s) / APK(s) > Build APK(s)**. The output is normally `android/app/build/outputs/apk/debug/app-debug.apk`.

This environment did not compile the APK. The supplied Android project is source code, not an already-built APK. Test on a spare device before relying on it.

## Next development step for live voice
Add a secure backend and integrate a telephony provider plus a real-time voice model. Keep API keys server-side; do not embed secrets in the APK. Call recording and personal-data retention require clear consent and appropriate safeguards.
