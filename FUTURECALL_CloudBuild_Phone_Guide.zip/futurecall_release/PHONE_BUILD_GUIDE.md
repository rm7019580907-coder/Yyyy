# Build an installable FUTURECALL APK using only your Android phone

This package includes Android source code and a GitHub Actions workflow that builds a debug APK in GitHub's cloud. It does not itself contain an APK.

## Steps
1. Download and extract this ZIP on your phone using Files > Downloads > the ZIP > Extract.
2. In Chrome, open https://github.com/new and create a repository named `futurecall-research`. For easiest setup, choose Public (or use Private if you know how to enable Actions for it).
3. Open the new empty repository. Tap `Add file` > `Upload files`.
4. Upload the contents of the extracted `futurecall_release` folder, including the hidden `.github` folder. If your phone's file picker hides `.github`, use GitHub's web editor to create `.github/workflows/build-apk.yml` and paste the workflow contents from the ZIP. Make sure `android/` and `www/` are uploaded at the repository root.
5. Commit the files to the `main` branch.
6. Open the repository's `Actions` tab. Select `Build FUTURECALL APK` and tap `Run workflow` if it has not started automatically.
7. Wait for the workflow to finish with a green check. Open that run and find `Artifacts`; download `FUTURECALL-debug-apk`.
8. Extract the downloaded artifact ZIP and tap `app-debug.apk`. If Android blocks the install, allow Chrome or Files to install unknown apps for this one installation, then retry.

Safety: this is a debug-signed prototype, not a Play Store release. Only install an APK you built from this source and keep your repository private if you do not want to publish your source. This prototype does not yet make real phone calls or communicate with an actual future self.
